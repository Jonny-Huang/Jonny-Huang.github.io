import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'emp-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.scss']
})
export class CalendarComponent implements OnInit {
  selectedDay: Date;
  selectedMonth = '';
  dayHeaders = ['日', '一', '二', '三', '四', '五', '六'];
  dayColors = ['red', 'white', 'white', 'white', 'white', 'white', 'green'];
  days = [];
  lastMonth_colspan = 0;
  constructor() { }

  ngOnInit() {
    this.getToday();
  }
  getToday() {
    this.selectedDay = new Date();
    this.getDay(0);
  }

  getDay(addDMonth: number) {
    let year = this.selectedDay.getFullYear();
    let month = this.selectedDay.getMonth() + addDMonth;
    const dt = new Date(year, month, 1);
    year = dt.getFullYear();
    month = dt.getMonth();

    this.lastMonth_colspan = new Date(year, month, 1).getDay();
    console.log(this.lastMonth_colspan);
    const _days = [];
    for (let day = 1; day <= 31; day++) {
      const time = new Date(year, month, day);
      if (time.getMonth() > month) {
        break;
      }
      const d: any = {
        day: day,
        week: time.getDay()
      };
      _days.push(d);
    }
    this.days = [..._days];

    this.selectedDay = new Date(year, month, 1);
    month++;
    // month為13時表示隔年的1月。
    if (month === 13) {
      month = 1;
      year++;
    }
    this.selectedMonth = `${year} 年 ${month} 月`;
  }
}

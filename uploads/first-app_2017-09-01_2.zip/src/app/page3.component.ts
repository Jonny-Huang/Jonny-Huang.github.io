import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page3',
  template: `
    <p>
      page3 works!
    </p>
  `
})

export class Page3Component implements OnInit {
  constructor() { }

  ngOnInit() { }
}

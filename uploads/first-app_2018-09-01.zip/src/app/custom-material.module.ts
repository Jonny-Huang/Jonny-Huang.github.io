import { NgModule } from '@angular/core';
import { MdIconModule } from '@angular/material';

@NgModule({
  imports: [MdIconModule],
  exports: [MdIconModule]
})
export class CustomMaterialModule { }

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page2',
  template: `
    <p>
      page2 Works!
    </p>
  `,
  styles: []
})
export class Page2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

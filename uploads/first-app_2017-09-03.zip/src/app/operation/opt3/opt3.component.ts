import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-opt3',
  templateUrl: './opt3.component.html',
  styleUrls: ['./opt3.component.scss']
})
export class Opt3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

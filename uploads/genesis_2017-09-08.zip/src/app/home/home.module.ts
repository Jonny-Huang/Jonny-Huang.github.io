import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';
import { IndexComponent } from './index/index.component';
import { ClarityModule } from 'clarity-angular';
import { HeaderComponent } from './header/header.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { SubnavComponent } from './subnav/subnav.component';

@NgModule({
  imports: [
    CommonModule,
    HomeRoutingModule,
    ClarityModule.forChild(),
  ],
  declarations: [
    IndexComponent,
    HeaderComponent,
    SidenavComponent,
    SubnavComponent
  ]
})
export class HomeModule { }

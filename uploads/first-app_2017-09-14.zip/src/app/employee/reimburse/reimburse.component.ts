import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'emp-reimburse',
  templateUrl: './reimburse.component.html',
  styleUrls: ['./reimburse.component.scss']
})
export class ReimburseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

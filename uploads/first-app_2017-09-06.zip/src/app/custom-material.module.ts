import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import {
  MdIconModule,
  MdButtonModule,
  MdListModule,
  MdToolbarModule,
  MdTooltipModule,
  MdSidenavModule
} from '@angular/material';

@NgModule({
  imports: [
    FlexLayoutModule,
    MdIconModule,
    MdButtonModule,
    MdListModule,
    MdToolbarModule,
    MdTooltipModule,
    MdSidenavModule
  ],
  exports: [
    FlexLayoutModule,
    MdIconModule,
    MdButtonModule,
    MdListModule,
    MdToolbarModule,
    MdTooltipModule,
    MdSidenavModule
  ]
})
export class CustomMaterialModule { }

import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MdIconModule } from '@angular/material';

@NgModule({
  imports: [
    FlexLayoutModule,
    MdIconModule
  ],
  exports: [
    FlexLayoutModule,
    MdIconModule
  ]
})
export class CustomMaterialModule { }

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-opt2',
  templateUrl: './opt2.component.html',
  styleUrls: ['./opt2.component.scss']
})
export class Opt2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

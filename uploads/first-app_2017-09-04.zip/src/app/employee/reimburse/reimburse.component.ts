import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reimburse',
  templateUrl: './reimburse.component.html',
  styleUrls: ['./reimburse.component.scss']
})
export class ReimburseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

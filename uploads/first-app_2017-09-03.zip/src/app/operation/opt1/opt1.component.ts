import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-opt1',
  templateUrl: './opt1.component.html',
  styleUrls: ['./opt1.component.scss']
})
export class Opt1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

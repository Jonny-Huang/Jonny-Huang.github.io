import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'emp-leave',
  templateUrl: './leave.component.html',
  styleUrls: ['./leave.component.scss']
})
export class LeaveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

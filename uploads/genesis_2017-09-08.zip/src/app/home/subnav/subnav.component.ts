import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'home-subnav',
  templateUrl: './subnav.component.html',
  styleUrls: ['./subnav.component.scss']
})
export class SubnavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'emp-file',
  templateUrl: './file.component.html',
  styleUrls: ['./file.component.scss']
})
export class FileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'emp-logbook',
  templateUrl: './logbook.component.html',
  styleUrls: ['./logbook.component.scss']
})
export class LogbookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

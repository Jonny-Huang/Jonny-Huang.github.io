import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'emp-to-do-list',
  templateUrl: './to-do-list.component.html',
  styleUrls: ['./to-do-list.component.scss']
})
export class ToDoListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
